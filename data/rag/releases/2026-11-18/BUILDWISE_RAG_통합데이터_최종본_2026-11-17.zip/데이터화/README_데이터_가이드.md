# BUILDWISE RAG 최종 데이터 가이드

1. ID_충돌_및_조인_가이드.md — ID 규칙, 중복 처리, 조인 방법
2. 데이터_사전.md — 파일 및 컬럼의 상세 의미
3. normalized/id_namespace_summary.csv 및 id_collision_report.csv — ID 상태
4. normalized/source_master.csv 및 source_id_map.csv — 출처 사전과 원본 ID 연결
5. normalized 폴더의 나머지 CSV/JSONL — 최종 통합 데이터

CSV/JSONL에는 전역 crawl_id와 URL별 source_key가 적용되어 있습니다. 루트의 원본 대조용 CSV/JSONL에는 원본 ID가 보존됩니다. 두 계층의 차이는 데이터 사전에 설명했습니다.

이 최종본은 두 시트의 발췌·정리 데이터를 통합한 결과입니다. 공식 웹페이지 전체 원문을 내려받은 코퍼스는 아닙니다.
