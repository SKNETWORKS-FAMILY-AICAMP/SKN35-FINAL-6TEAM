# ID 충돌 및 조인 가이드
기준일: 2026-11-17

## 적용한 ID 번호
- 진봉 원문: 전역 crawl_id CRAWL-001~CRAWL-062
- 성욱 원문: 전역 crawl_id CRAWL-063~CRAWL-147
- 두 원문에 원래 있던 crawl_id는 original_crawl_id로 보존했습니다.
- 문서 출처는 정규 source_key SOURCE-001~SOURCE-083입니다. 진봉 자료 URL을 먼저 번호 매기고 성욱 자료에만 있는 URL을 뒤에 배정했습니다.
- 양쪽이 같은 URL 문서를 가리키면 하나의 source_key를 함께 씁니다. 이 값은 출처 외래 키라서 여러 크롤 행에서 반복되는 것이 정상입니다.
- 원본 source_id는 original_source_id로 보존하고, RAG 근거/청크/크롤 행의 source_key와 source_id에는 정규 SOURCE 키를 사용합니다.

## 무엇이 실제로 겹쳤나요?
원본 crawl_id 62개가 양쪽 시트에 각각 존재했고, 해당 62쌍은 16개 원문 필드가 일치했습니다. 이것은 복사된 같은 내용이지만 로컬 ID가 중복된 경우라 전역 번호로 분리했습니다.
원본 source_id 62개도 양쪽 시트에 반복됩니다. 이 값은 같은 URL 출처를 가리키므로 각 행마다 다른 출처 ID를 만들지 않았습니다. 별칭 연결은 source_id_map.csv에 남기고 동일 문서는 동일 SOURCE 키로 통합했습니다. 별칭 168개 중 서로 다른 문서를 가리키는 충돌은 0건입니다.

## 먼저 볼 파일
1. 통합 Excel의 ID_배정 탭
2. normalized/global_id_assignment.csv — 147개 행의 새 crawl_id와 원본 ID
3. normalized/source_key_assignment.csv — 83개 문서의 source_key 순서
4. normalized/crawl_records_normalized.csv — 전역 crawl_id와 정규 source_key
5. normalized/source_master.csv 및 source_id_map.csv
6. id_collision_report.csv — 원래 겹친 ID와 해결 결과
7. 데이터_사전.md — 테이블별 모든 컬럼 설명

## 주요 키
- crawl_id: 크롤 기록의 새 PK. 전역에서 147개 모두 고유합니다.
- original_crawl_id: 원본 시트 로컬 ID. 추적용이지 조인용 PK가 아닙니다.
- source_key / source_id: 정규 출처 외래 키 SOURCE-001~083. 같은 문서를 가리키는 여러 행에서 반복될 수 있습니다.
- original_source_id: 원본 출처 별칭. source_id_map으로 source_key에 연결합니다.
- fact_key, chunk_key, coverage_key: 진봉 자료의 근거·청크·범위 ID에 JINBONG 접두사를 붙인 키입니다.

## 관계도
~~~mermaid
erDiagram
  SOURCE_MASTER ||--o{ CRAWL_RECORD : source_key
  SOURCE_MASTER ||--o{ RAG_FACT : source_key
  SOURCE_MASTER ||--o{ RAG_CHUNK : source_key
  SOURCE_MASTER ||--o{ SOURCE_ID_MAP : aliases
  CRAWL_RECORD ||--o{ CRAWL_CHUNK_MAP : crawl_id
  RAG_CHUNK ||--o{ CRAWL_CHUNK_MAP : chunk_key
  BRAND_SCOPE ||--o{ BRAND_SCOPE_SOURCE_MAP : coverage_key
  SOURCE_MASTER ||--o{ BRAND_SCOPE_SOURCE_MAP : source_key
~~~

## 조인 예시
~~~sql
SELECT c.crawl_id, c.source_key, s."정규 URL", c.normalized_text
FROM crawl_records_normalized AS c
JOIN source_master AS s ON s.source_key = c.source_key;

SELECT ch.chunk_key, ch.chunk_text, s."발행처", s."문서명", s."정규 URL"
FROM rag_chunks_normalized AS ch
JOIN source_master AS s ON s.source_key = ch.source_key;

SELECT m.crawl_id, ch.chunk_key, ch.chunk_text
FROM crawl_chunk_map AS m
JOIN rag_chunks_normalized AS ch ON ch.chunk_key = m.chunk_key
WHERE m.crawl_id = 'CRAWL-063';
~~~

## 참고
- crawl_id만 보면 중복은 해결됐지만 원문 대조/출처 추적이 필요하면 original_crawl_id와 crawl_key를 확인하세요.
- source_id가 반복되는 것은 출처 외래 키로서 정상입니다. 서로 다른 출처인지 확인할 때는 source_id_map의 mapping_status를 보세요.
- 같은 ASUS FAQ URL의 내용·해시가 다른 크롤 행은 별도 기록으로 유지했습니다.
- 이 패키지는 시트에 저장된 발췌/정리 텍스트이며 공식 페이지 전체 HTML/PDF를 전부 내려받은 결과가 아닙니다.
