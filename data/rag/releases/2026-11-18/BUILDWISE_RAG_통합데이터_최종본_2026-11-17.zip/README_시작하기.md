# BUILDWISE RAG 데이터 통합 최종본

최종본 기준일: 2026-11-17

## 최종 파일
- BUILDWISE_RAG_데이터_통합_최종본_2026-11-17.xlsx: 사람이 확인하는 통합 Excel, ID_배정 탭 포함
- BUILDWISE_RAG_통합데이터_최종본_2026-11-17.zip: Excel, 데이터 가이드, 데이터 사전, ID 충돌 보고서, CSV/JSONL 정규화 데이터 포함
- Google Sheets 최종본: https://docs.google.com/spreadsheets/d/1OOguiAQCe1_D4CHUZweHut-FTDGw36N0BuO9Ws6_sZ0/edit

## 읽는 순서
1. 데이터화/ID_충돌_및_조인_가이드.md
2. 데이터화/데이터_사전.md
3. Excel의 ID_배정 탭 또는 ZIP의 global_id_assignment.csv와 source_key_assignment.csv
4. 데이터화/normalized 폴더의 정규화 CSV/JSONL

진봉 크롤 행에는 CRAWL-001~062, 성욱 크롤 행에는 CRAWL-063~147을 배정했습니다. 출처는 진봉 URL부터 SOURCE-001~062, 성욱 전용 URL에 SOURCE-063~083입니다. 같은 URL의 출처 키는 공유됩니다.

## 최종본 범위
현재 두 원본 시트에 저장된 발췌·정리 데이터를 합치고 ID와 연결 관계를 정리한 최종본입니다. 원본 시트는 수정하지 않았습니다. 공식 웹페이지 전체 HTML/PDF는 수집 패키지에 포함하지 않았고, 출처 문서에 미등록된 URL은 검토 상태로 남았습니다.
